#!/bin/bash
echo "当前进程号:"$$
echo "start"
sleep 10
kill $$
echo "stop"
