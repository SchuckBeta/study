#!/bin/bash
while [ $1 -gt 2 ]
do

echo "true"
sleep 1
done
