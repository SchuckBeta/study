#!/bin/bash

for j in $@
do
echo $j
done
echo '-------------'
for j in "$@"
do
echo $j
done
echo '-------------'
for j in $*
do
echo $j
done
echo '-------------'
for j in "$*"
do
echo $j
done
