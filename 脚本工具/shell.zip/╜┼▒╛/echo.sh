source fun.sh

clear
echo -e "\t\tsystem admin menu"
echo -e "\t1.get current time"
echo -e "\t2.ls command"
echo -ne "\t\tEnter option: "
read option

case $option in
1)
currtime
;;
2)
ls
;;
*)
echo "sorry no this option"
;;
esac

