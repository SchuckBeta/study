#!/bin/bash
if [ $1 -eq 1 ] 
then
echo 'one'
else
echo 'none'
fi
