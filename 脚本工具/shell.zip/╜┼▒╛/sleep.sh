#!/bin/bash
echo 'start'

sleep 100000000000

echo 'stop'
