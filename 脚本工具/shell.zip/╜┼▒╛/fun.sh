#!/bin/bash
function currtime(){
echo "current time is"`date +%Y-%m-%d`
}
