#!/bin/bash
while [ 1 -eq 1 ]
do

for ((i=0;i<10;i++))
do
if [ $i -eq 2 ]
then
break
fi
echo $i
done
echo 'yes'
sleep 1
done

