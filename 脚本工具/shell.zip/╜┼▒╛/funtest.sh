#!/bin/bash
source fun.sh

test $1
