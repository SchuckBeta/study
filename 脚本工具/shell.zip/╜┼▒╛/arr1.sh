#!/bin/bash
for i in {0..4}
do
num[$i]=$i
done

for j in ${num[@]}
do
echo $j
done
echo '-------------'
for j in "${num[@]}"
do
echo $j
done
echo '-------------'
for j in ${num[*]}
do
echo $j
done
echo '-------------'
for j in "${num[*]}"
do
echo $j
done
