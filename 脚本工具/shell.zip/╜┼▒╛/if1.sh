#!/bin/bash
if [ $1 -eq 1 ] 
then
echo 'one'
elif [ $1 -eq 2 ]
then
echo 'two'
elif [ $1 -eq 3 ]
then
echo 'three'
else
echo 'none'
fi
